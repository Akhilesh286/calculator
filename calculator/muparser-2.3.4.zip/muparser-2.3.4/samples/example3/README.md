The example3 shows how to import and use muparser as an installed external
dependency using cmake `find_package()`.
